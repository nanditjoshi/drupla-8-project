<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'chang', 'zhi', 'bing', 'jiu', 'yao', 'cui', 'lia', 'wan', 'lai', 'cang', 'zong', 'ge', 'guan', 'bei', 'tian', 'shu',
  0x10 => 'shu', 'men', 'dao', 'tan', 'jue', 'chui', 'xing', 'peng', 'tang', 'hou', 'yi', 'qi', 'ti', 'gan', 'jing', 'jie',
  0x20 => 'sui', 'chang', 'jie', 'fang', 'zhi', 'kong', 'juan', 'zong', 'ju', 'qian', 'ni', 'lun', 'zhuo', 'wo', 'luo', 'song',
  0x30 => 'leng', 'hun', 'dong', 'zi', 'ben', 'wu', 'ju', 'nai', 'cai', 'jian', 'zhai', 'ye', 'zhi', 'sha', 'qing', 'qie',
  0x40 => 'ying', 'cheng', 'jian', 'yan', 'ruan', 'zhong', 'chun', 'jia', 'ji', 'wei', 'yu', 'bing', 'ruo', 'ti', 'wei', 'pian',
  0x50 => 'yan', 'feng', 'tang', 'wo', 'e', 'xie', 'che', 'sheng', 'kan', 'di', 'zuo', 'cha', 'ting', 'bei', 'xie', 'huang',
  0x60 => 'yao', 'zhan', 'chou', 'yan', 'you', 'jian', 'xu', 'zha', 'ci', 'fu', 'bi', 'zhi', 'zong', 'mian', 'ji', 'yi',
  0x70 => 'xie', 'xun', 'cai', 'duan', 'ce', 'zhen', 'ou', 'tou', 'tou', 'bei', 'za', 'lou', 'jie', 'wei', 'fen', 'chang',
  0x80 => 'gui', 'sou', 'zhi', 'su', 'xia', 'fu', 'yuan', 'rong', 'li', 'nu', 'yun', 'jiang', 'ma', 'bang', 'dian', 'tang',
  0x90 => 'hao', 'jie', 'xi', 'shan', 'qian', 'jue', 'cang', 'chu', 'san', 'bei', 'xiao', 'yong', 'yao', 'tan', 'suo', 'yang',
  0xA0 => 'fa', 'bing', 'jia', 'dai', 'zai', 'tang', 'gu', 'bin', 'chu', 'nuo', 'can', 'lei', 'cui', 'yong', 'zao', 'zong',
  0xB0 => 'beng', 'song', 'ao', 'chuan', 'yu', 'zhai', 'zu', 'shang', 'chuang', 'jing', 'chi', 'sha', 'han', 'zhang', 'qing', 'yan',
  0xC0 => 'di', 'xie', 'lou', 'bei', 'piao', 'jin', 'lian', 'lu', 'man', 'qian', 'xian', 'tan', 'ying', 'dong', 'zhuan', 'xiang',
  0xD0 => 'shan', 'qiao', 'jiong', 'tui', 'zun', 'pu', 'xi', 'lao', 'chang', 'guang', 'liao', 'qi', 'cheng', 'chan', 'wei', 'ji',
  0xE0 => 'bo', 'hui', 'chuan', 'tie', 'dan', 'jiao', 'jiu', 'seng', 'fen', 'xian', 'ju', 'e', 'jiao', 'jian', 'tong', 'lin',
  0xF0 => 'bo', 'gu', 'xian', 'su', 'xian', 'jiang', 'min', 'ye', 'jin', 'jia', 'qiao', 'pi', 'feng', 'zhou', 'ai', 'sai',
];
